// mysigcatchmodified.c
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

// Global counter for SIGINT signals
volatile sig_atomic_t sigint_count = 0;

// Signal handler function
void custom_sigint_handler(int sig) {
    sigint_count++;

    // Print the signal number and a custom message
    printf("\nCaught SIGINT (Signal Number: %d). Count: %d\n", sig, sigint_count);

    if (sigint_count >= 2) {
        printf("SIGINT caught twice. Restoring default handler.\n");

        // Restore default SIGINT behavior
        struct sigaction sa_default;
        memset(&sa_default, 0, sizeof(sa_default));
        sa_default.sa_handler = SIG_DFL;

        if (sigaction(SIGINT, &sa_default, NULL) == -1) {
            perror("Error restoring default SIGINT handler");
            exit(EXIT_FAILURE);
        }

        printf("Default SIGINT behavior restored. Press Ctrl+C again to terminate.\n");
    }
}

int main() {
    // Structure to specify the new action
    struct sigaction sa;

    // Clear the sigaction structure
    memset(&sa, 0, sizeof(sa));

    // Set the custom handler
    sa.sa_handler = custom_sigint_handler;

    // Block every signal during the handler
    sigfillset(&sa.sa_mask);

    // No special flags
    sa.sa_flags = 0;

    // Register the signal handler for SIGINT
    if (sigaction(SIGINT, &sa, NULL) == -1) {
        perror("Error registering SIGINT handler");
        exit(EXIT_FAILURE);
    }

    printf("mysigcatchmodified.c is running. Press Ctrl+C to send SIGINT.\n");
    printf("After two SIGINTs, default behavior will be restored.\n");

    // Infinite loop to keep the program running
    while (1) {
        pause(); // Wait for signals
    }

    return 0;
}
