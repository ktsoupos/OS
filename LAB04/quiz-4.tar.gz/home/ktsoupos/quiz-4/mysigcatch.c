// mysigcatch.c
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

// Function prototype for the signal handler
void handle_sigint(int sig);

// Signal handler function
void handle_sigint(int sig) {
    // Print the message upon catching SIGINT
    printf("\nSIGINT signal caught!\n");
    
    // Perform any necessary cleanup here (if applicable)

    // Exit the program gracefully
    exit(0);
}

int main() {
    // Register the signal handler for SIGINT
    if (signal(SIGINT, handle_sigint) == SIG_ERR) {
        perror("Error registering signal handler");
        return 1;
    }

    printf("mysigcatch.c is running. Press Ctrl+C to send SIGINT.\n");

    // Infinite loop to keep the program running
    while (1) {
        // Sleep for a short duration to reduce CPU usage
        sleep(1);
    }

    return 0;
}
